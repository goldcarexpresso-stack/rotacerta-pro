# Roadmap

## Próximo
- Login real Firebase Auth.
- Firestore para rotas e pacotes.
- Firebase Storage para fotos.
- QR Code e código de barras em tempo real.
- Pagamento Premium real.
- Painel administrativo online.
