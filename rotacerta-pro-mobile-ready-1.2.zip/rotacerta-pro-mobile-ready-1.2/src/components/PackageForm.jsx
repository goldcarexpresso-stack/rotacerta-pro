import React,{useState} from 'react';
import {readImage} from '../utils/storage.js';
import {readLabel} from '../services/ocr.js';
export default function PackageForm({t,onAdd}){
  const [pkg,setPkg]=useState({code:'',address:'',district:'',photo:null,labelPhoto:null,notes:''});
  const setField=(k,v)=>setPkg(p=>({...p,[k]:v}));
  const img=async(k,file)=>file && setField(k,await readImage(file));
  const ocr=async(file)=>{const text=await readLabel(file); setPkg(p=>({...p,labelPhoto:p.labelPhoto,code:p.code||text.match(/[A-Z0-9#_-]{3,}/i)?.[0]||'',address:p.address||text.trim()}));};
  return <div className="form"><input placeholder={t.packageId} value={pkg.code} onChange={e=>setField('code',e.target.value)}/><input placeholder={t.address} value={pkg.address} onChange={e=>setField('address',e.target.value)}/><input placeholder={t.district} value={pkg.district} onChange={e=>setField('district',e.target.value)}/><input placeholder="Observação" value={pkg.notes} onChange={e=>setField('notes',e.target.value)}/><label className="file">📦 Foto<input hidden type="file" accept="image/*" onChange={e=>img('photo',e.target.files?.[0])}/></label><label className="file">🏷️ Etiqueta/OCR<input hidden type="file" accept="image/*" onChange={async e=>{const f=e.target.files?.[0]; await img('labelPhoto',f); await ocr(f);}}/></label><button onClick={()=>{if(!pkg.code)return alert('Informe o identificador do pacote.'); onAdd(pkg); setPkg({code:'',address:'',district:'',photo:null,labelPhoto:null,notes:''});}}>+ {t.add}</button></div>;
}
