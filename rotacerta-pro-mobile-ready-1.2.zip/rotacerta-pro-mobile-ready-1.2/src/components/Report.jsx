import React from 'react';
import {googleMapsRoute} from '../services/maps.js';
import {downloadCSV} from '../utils/csv.js';
export default function Report({t,route}){
  const delivered=route.packages.filter(p=>p.status==='delivered').length;
  const positioned=route.packages.filter(p=>p.x!=null).length;
  const photos=route.packages.filter(p=>p.photo||p.labelPhoto).length;
  return <div className="card"><h2>📊 {t.report}</h2><div className="mind"><b>📦 {route.packages.length}<br/><small>{t.packages}</small></b><b>✅ {delivered}<br/><small>{t.delivered}</small></b><b>📍 {positioned}<br/><small>posicionados</small></b><b>📸 {photos}<br/><small>fotos</small></b></div><p>Mapa mental de benefícios: organização da carga, busca rápida por pacote, rota no Google Maps e relatório final.</p><a className="button" target="_blank" href={googleMapsRoute(route.packages)}>🗺️ {t.map}</a><button className="ghost" onClick={()=>downloadCSV(route.packages)}>{t.exportCsv}</button></div>;
}
