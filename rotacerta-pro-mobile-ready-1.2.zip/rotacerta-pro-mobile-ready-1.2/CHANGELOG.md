# Changelog

## 1.2.0
- Projeto reorganizado para estrutura React/Vite profissional.
- Preparado para fluxo de trabalho pelo celular: ZIP > GitHub > Vercel.
- Adicionado Firebase preparado por `.env.example`.
- Adicionado PWA, mapa da carga, OCR, CSV, Google Maps e relatório.
